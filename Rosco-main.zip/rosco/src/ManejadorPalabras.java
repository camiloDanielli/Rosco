import java.util.ArrayList;

public class ManejadorPalabras {

	private ArrayList<Palabra> palabra;

	public ManejadorPalabras() {

		this.palabra = new ArrayList<Palabra>();
	}

	public void crearNuevaPalabra(char letra, String definicion, int codigo, boolean empiezaPor, boolean estadoUSO,
			int cantidadRespondida, int cantidadRespondidaCorrectamente) {

		this.palabra.add(new Palabra(letra, definicion, codigo, empiezaPor, estadoUSO, cantidadRespondida,
				cantidadRespondidaCorrectamente, null));
	}

	public void eliminarPalabra(char letra, String definicion, int codigo, boolean empiezaPor, boolean estadoUSO,
			int cantidadRespondida, int cantidadRespondidaCorrectamente) {
		palabra = null;
		System.gc();
	}

	
	
	@SuppressWarnings("null")
	public void nuevaPartida(String nickname,int pin) {
		Partida partida = null;
		partida.set
	}
	
	

	}
