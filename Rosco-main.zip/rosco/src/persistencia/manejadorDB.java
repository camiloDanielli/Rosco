package persistencia;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class manejadorDB {

	public void delPalabra(int codigo) throws SQLException {           ///////////////////
		DBConf dbconf = new DBConf();
		Connection con = dbconf.conectarMySQL();

		Statement stmt = con.createStatement();
		String delete = "DELETE FROM (Table Palabra) WHERE codigo = " + codigo ;

		try {
		stmt.executeUpdate(delete);
		} catch (SQLException e) {
		System.out.println(e.getMessage());
		}  

		}
}
