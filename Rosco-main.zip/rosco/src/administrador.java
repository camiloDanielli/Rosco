
public class administrador extends Usuario {

	public administrador(int ci, String nombre, String apellido, String mail, int pin) {
		super(ci, nombre, apellido, mail, pin);
	}

}
