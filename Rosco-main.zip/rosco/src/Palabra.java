public class Palabra  {
private char letra;
private String definicion;
private int codigo;
private boolean empiezaPor;
private boolean estadoUSO;
private int cantResp;
private int cantRespCorrecta;
private Categoria categoria;
public Palabra(char letra, String definicion, int codigo, boolean empiezaPor, boolean estadoUSO, int cantResp,
		int cantRespCorrecta, Categoria categoria) {
	super();
	this.letra = letra;
	this.definicion = definicion;
	this.codigo = codigo;
	this.empiezaPor = empiezaPor;
	this.estadoUSO = estadoUSO;
	this.cantResp = cantResp;
	this.cantRespCorrecta = cantRespCorrecta;
	this.categoria = categoria;
}
public char getLetra() {
	return letra;
}
public void setLetra(char letra) {
	this.letra = letra;
}
public String getDefinicion() {
	return definicion;
}
public void setDefinicion(String definicion) {
	this.definicion = definicion;
}
public int getCodigo() {
	return codigo;
}
public void setCodigo(int codigo) {
	this.codigo = codigo;
}
public boolean isEmpiezaPor() {
	return empiezaPor;
}
public void setEmpiezaPor(boolean empiezaPor) {
	this.empiezaPor = empiezaPor;
}
public boolean isEstadoUSO() {
	return estadoUSO;
}
public void setEstadoUSO(boolean estadoUSO) {
	this.estadoUSO = estadoUSO;
}
public int getCantResp() {
	return cantResp;
}
public void setCantResp(int cantResp) {
	this.cantResp = cantResp;
}
public int getCantRespCorrecta() {
	return cantRespCorrecta;
}
public void setCantRespCorrecta(int cantRespCorrecta) {
	this.cantRespCorrecta = cantRespCorrecta;
}
public Categoria getCategoria() {
	return categoria;
}
public void setCategoria(Categoria categoria) {
	this.categoria = categoria;
}

}