package com.pasapalabraapi.logic;

public class Partida{
private int codigo;
private String nickname;
private boolean finalizada;
private int puntaje;
private Jugador jugador;
private Palabra[] palabra;
public Partida(int codigo, String nickname, boolean finalizada, int puntaje, Jugador jugador, Palabra[] palabra) {
	super();
	this.codigo = codigo;
	this.nickname = nickname;
	this.finalizada = finalizada;
	this.puntaje = puntaje;
	this.jugador = jugador;
	this.palabra = palabra;
}
public int getCodigo() {
	return codigo;
}
public void setCodigo(int codigo) {
	this.codigo = codigo;
}
public String getNickname() {
	return nickname;
}
public void setNickname(String nickname) {
	this.nickname = nickname;
}
public boolean isFinalizada() {
	return finalizada;
}
public void setFinalizada(boolean finalizada) {
	this.finalizada = finalizada;
}
public int getPuntaje() {
	return puntaje;
}
public void setPuntaje(int puntaje) {
	this.puntaje = puntaje;
}
public Jugador getJugador() {
	return jugador;
}
public void setJugador(Jugador jugador) {
	this.jugador = jugador;
}
public Palabra[] getPalabra() {
	return palabra;
}
public void setPalabra(Palabra[] palabra) {
	this.palabra = palabra;
}

}
