package com.pasapalabraapi.logic;

public class manejadorPartida {

}
