package com.pasapalabraapi.logic;
import java.sql.SQLException;
import java.util.ArrayList;
import com.pasapalabraapi.persistence.manejadorDB;


public class ManejadorPalabras {
	manejadorDB manejadorDB = new manejadorDB();


	public void crearNuevaPalabra(char letra, String definicion, int codigo, boolean empiezaPor, boolean estadoUSO,
			int cantidadRespondida, int cantidadRespondidaCorrectamente) throws SQLException {
		manejadorDB.nuevaPalabra(letra,definicion,codigo,empiezaPor,estadoUSO,cantidadRespondida,cantidadRespondidaCorrectamente);
	}
	
	public void elimiarPalabra(int codigo) throws SQLException {  /////////////////// /////////////////// ///////////////////
		manejadorDB.delPalabra(codigo);
		}

	public void getPalabras(char letra) throws SQLException {  /////////////////// /////////////////// ///////////////////
		manejadorDB.getPalabra(letra);
		
		} 
	}
