package com.pasapalabraapi.logic;

public class Jugador extends Usuario {

	private String nickName;
	private int partidasGanadas;
	private int partidasPerdidas;
	
public Jugador(int ci, String nombre, String apellido, String mail, int pin, String nickName, int partidasGanadas, int partidasPerdidas) {
		super(ci, nombre, apellido, mail, pin);
		// TODO Auto-generated constructor stub
		this.nickName = nickName;
		this.partidasGanadas = partidasGanadas;
		this.partidasPerdidas = partidasPerdidas;
	}

public String getNickName() {
	return nickName;
}

public void setNickName(String nickName) {
	this.nickName = nickName;
}

public int getPartidasGanadas() {
	return partidasGanadas;
}

public void setPartidasGanadas(int partidasGanadas) {
	this.partidasGanadas = partidasGanadas;
}

public int getPartidasPerdidas() {
	return partidasPerdidas;
}

public void setPartidasPerdidas(int partidasPerdidas) {
	this.partidasPerdidas = partidasPerdidas;
}


}

