package com.pasapalabraapi.logic;
import java.util.ArrayList;

public class Categoria {
private String nombre;

private ArrayList<Palabra> Palabras;

public Categoria( String nombre) {
	super();
	this.nombre = nombre;
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public ArrayList<Palabra> getPalabras() {
	return Palabras;
}

public void setPalabras(ArrayList<Palabra> palabras) {
	Palabras = palabras;
}

}