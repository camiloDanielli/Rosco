import java.util.ArrayList;

public class ManejadorPalabras {

	private ArrayList<Palabra> palabra;

	public ManejadorPalabras() {

		this.palabra = new ArrayList<Palabra>();
	}

	public void crearNuevaPalabra(char letra, String definicion, int codigo, boolean empiezaPor, boolean estadoUSO,
			int cantidadRespondida, int cantidadRespondidaCorrectamente) {

		this.palabra.add(new Palabra(letra, definicion, codigo, empiezaPor, estadoUSO, cantidadRespondida,
				cantidadRespondidaCorrectamente));
	}

	public void eliminarPalabra(char letra, String definicion, int codigo, boolean empiezaPor, boolean estadoUSO,
			int cantidadRespondida, int cantidadRespondidaCorrectamente) {
		palabra = null;
		System.gc();
	}

	public void obtenerPalabras() {
		char letras[] = new char[99];
		letras[0] = 'A';
		letras[1] = 'B';
		letras[2] = 'C';
		letras[3] = 'D';
		letras[4] = 'E';
		letras[5] = 'F';
		letras[6] = 'G';
		letras[7] = 'H';
		letras[8] = 'I';
		letras[9] = 'J';
		letras[10] = 'L';
		letras[11] = 'M';
		letras[12] = 'N';
		letras[13] = '�';
		letras[14] = 'O';
		letras[15] = 'P';
		letras[16] = 'Q';
		letras[17] = 'R';
		letras[18] = 'S';
		letras[19] = 'T';
		letras[20] = 'U';
		letras[21] = 'V';
		letras[22] = 'X';
		letras[23] = 'Y';
		letras[24] = 'Z';
		for (int i = 0; i < letras.length; i++) {
		}
		String palabras[] = new String[99];
		//A
		palabras[0] = "Aviones";
		palabras[1]="Atributos";
		palabras[2]="Autorelacion";
		palabras[3]="Agregacion";
		//B
		palabras[4]="Bases";
		palabras[5]="Boostrap";
		palabras[6]="Backend";
		palabras[7]="Bash";
		//C
		palabras[8]="Cardinalidad";
		palabras[9]="Color";
		palabras[10]="Css";
		palabras[11]="Class";
		//D
		palabras[12]="Dise�o";
		palabras[13]="Desarrollo";
		palabras[14]="Datos";
		palabras[15]="Dependencia";
		//E
		palabras[16]="Estructura";
		palabras[17]="Electronica";
		palabras[18]="Entidades";
		palabras[19]="Estudiar";
		//F
		palabras[20]="Foreing key";
		palabras[21]="Formas normales";
		palabras[22]="funcionalidades";
		palabras[23]="Fallo";
		//G
		palabras[24]="Git";
		palabras[25]="Grid";
		palabras[26]="Codigo";
		palabras[27]="Greep";
		//H
		palabras[28]="Html";
		palabras[29]="Hardware";
		palabras[30]="Herencia";
		palabras[31]="Host";
		//I
		palabras[32]="Int";
		palabras[33]="Iterfaz";
		palabras[34]="APIs";
		palabras[35]="Div";
		//J
		palabras[36]="Java";
		palabras[37]="Javascrip";
		palabras[38]="Jpanel";
		palabras[39]="Caja";
		//L
		palabras[40]="Link";
		palabras[41]="Lenguaje";
		palabras[42]="Linea";
		palabras[43]="While";
		//M
		palabras[44]="Manejador";
		palabras[45]="Modelo";
		palabras[46]="M.E.R";
		palabras[47]="Main";
		//N
		palabras[48]="Negacion";
		palabras[49]="Not";
		palabras[50]="Null";
		palabras[51]="Name";
		//�
		palabras[52]="Dise�o";
		palabras[53]="Dise�ar";
		palabras[54]="A�adir";
		palabras[55]="Se�alar";
		//O
		palabras[56]="Origen";
		palabras[57]="Organizacion";
		palabras[58]="Opciones";
		palabras[59]="Or";
		//P
		palabras[60]="Programacion";
		palabras[61]="persistencia";
		palabras[62]="Proyecto";
		palabras[63]="Prioridad";
		//Q
		palabras[64]="Query";
		palabras[65]="My SQL";
		palabras[66]="Queue";
		palabras[67]="SQL";
		//R
		palabras[68]="Relacion";
		palabras[69]="Red";
		palabras[70]="Restriccion";
		palabras[71]="Resolucion";
		//S
		palabras[72]="Select";
		palabras[73]="Swing";
		palabras[74]="Seguridad";
		palabras[75]="Consi=ultas";
		//T
		palabras[76]="Timer";
		palabras[77]="Telcomunicaciones";
		palabras[78]="Tablas";
		palabras[79]="Tesla";
		//U
		palabras[80]="Usuario";
		palabras[81]="Utilidad";	
		palabras[82]="Usabilidad";
		palabras[83]="Union";
		//V
		palabras[84]="Variables";
		palabras[85]="Velocidad";
		palabras[86]="Var";
		palabras[87]="Vector";
		//X
		palabras[88]="Exacto";
		palabras[89]="Hexadecimal";
		palabras[90]="Xampp";
		palabras[91]="Example";
		//Y
		palabras[92]="Keynes";
		palabras[93]="Hayek";
		palabras[94]="Keynesianismo";
		palabras[95]="Hayekianos";
		//Z
		palabras[96]="Zoom,";
		palabras[97]="Z-index";
		palabras[98]="Normalizacion";
		palabras[99]="Zip";
		for (int i = 0; i < palabras.length; i++) {

		}

	}

}