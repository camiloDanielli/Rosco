public class Categoria extends Palabra {
private String nombre;

public Categoria(char letra, String definicion, int codigo, boolean empiezaPor, boolean estadoUSO,
		int cantidadRespondida, int cantidadRespondidaCorrectamente, String nombre) {
	super(letra, definicion, codigo, empiezaPor, estadoUSO, cantidadRespondida, cantidadRespondidaCorrectamente);
	this.nombre = nombre;
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
  
  
}

}