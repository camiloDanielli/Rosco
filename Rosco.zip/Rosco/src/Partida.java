public class Partida extends Palabra {
private int codigo;
private String nickname;
private boolean finalizada;
private int puntaje;
public Partida(char letra, String definicion, int codigo, boolean empiezaPor, boolean estadoUSO, int cantidadRespondida,
		int cantidadRespondidaCorrectamente, int codigo2, String nickname, boolean finalizada, int puntaje) {
	super(letra, definicion, codigo, empiezaPor, estadoUSO, cantidadRespondida, cantidadRespondidaCorrectamente);
	codigo = codigo2;
	this.nickname = nickname;
	this.finalizada = finalizada;
	this.puntaje = puntaje;
}
public int getCodigo() {
	return codigo;
}
public void setCodigo(int codigo) {
	this.codigo = codigo;
}
public String getNickname() {
	return nickname;
}
public void setNickname(String nickname) {
	this.nickname = nickname;
}
public boolean isFinalizada() {
	return finalizada;
}
public void setFinalizada(boolean finalizada) {
	this.finalizada = finalizada;
}
public int getPuntaje() {
	return puntaje;
}
public void setPuntaje(int puntaje) {
	this.puntaje = puntaje;
}


}
