public class Palabra  {
private char letra;
private String definicion;
private int codigo;
private boolean empiezaPor;
private boolean estadoUSO;
private int cantidadRespondida;
private int cantidadRespondidaCorrectamente;
public Palabra(char letra, String definicion, int codigo, boolean empiezaPor, boolean estadoUSO, int cantidadRespondida,
		int cantidadRespondidaCorrectamente) {
	super();
	this.letra = letra;
	this.definicion = definicion;
	this.codigo = codigo;
	this.empiezaPor = empiezaPor;
	this.estadoUSO = estadoUSO;
	this.cantidadRespondida = cantidadRespondida;
	this.cantidadRespondidaCorrectamente = cantidadRespondidaCorrectamente;
}
public char getLetra() {
	return letra;
}
public void setLetra(char letra) {
	this.letra = letra;
}
public String getDefinicion() {
	return definicion;
}
public void setDefinicion(String definicion) {
	this.definicion = definicion;
}
public int getCodigo() {
	return codigo;
}
public void setCodigo(int codigo) {
	this.codigo = codigo;
}
public boolean isEmpiezaPor() {
	return empiezaPor;
}
}