package com.pasapalabraapi.logic;

public class manejadorAdmins {

}
