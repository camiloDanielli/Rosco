package com.pasapalabraapi.persistence;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class manejadorDB {

	public  void delPalabra(int codigo) throws SQLException {           ///////////////////
		DBConf dbconf = new DBConf();
		Connection con = dbconf.conectarMySQL();

		Statement stmt = con.createStatement();
		String delete = "DELETE FROM (Table Palabra) WHERE codigo = " + codigo ;

		try {
		stmt.executeUpdate(delete);
		} catch (SQLException e) {
		System.out.println(e.getMessage());
		}  

		}

	public  void nuevaPalabra(char letra, String definicion, int codigo, boolean empiezaPor, int cantidadRespondida,
			int cantidadRespondidaCorrectamente, String palabra) {
		DBConf dbconf = new DBConf();
		Connection con = dbconf.conectarMySQL();

		Statement stmt = con.createStatement();
		String newWord = "insert FROM (Table Palabra) WHERE codigo = " + codigo ;

		try {
		stmt.executeUpdate(delete);
		} catch (SQLException e) {
		System.out.println(e.getMessage());
		}  

		
	}

	public  void getPalabra(char letra) {
		// TODO Auto-generated method stub
		
	}
}
